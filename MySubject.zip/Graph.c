#include<stdio.h>

#include "Graph.h"

#define PRINT_LEVEL 1

Graph* Graph_New( size_t size, eGraphType type ){

   assert( size > 0 );
   Graph* g = (Graph*) malloc( sizeof( Graph ) );
   if( g ){
   	g->size = size;
      g->len = 0;
      g->type = type;
      g->vertices = (Vertex*) calloc( size, sizeof( Vertex ) );
      if( g->vertices ){
         
         Vertex* vertices = g->vertices;
         
         for( size_t i = 0; i < g->size; ++i ){
            vertices[ i ].map.key = 0;
            vertices[ i ].map.data_idx = 0;
            vertices[ i ].neighbors = NULL;
         }
      } 
      
      else{ 
         free( g );
         g = NULL;
      }
   }
   return g;
}

void Graph_Delete( Graph** g )
{
   assert( *g );
   Graph* graph = *g;
   
   for( size_t i = 0; i < graph->size; ++i ){
      Vertex* vertex = &graph->vertices[ i ];

      Node* node = vertex->neighbors;
      while( node ){
         Node* tmp = node->next;
         free( node );
         node = tmp;
      }
   }
   free( graph->vertices );
   free( graph );
   *g = NULL;
}

void Graph_Print( Graph* g, int depth, Subject *materia )
{
   for( size_t i = 0; i < g->len; ++i ){
		
	  printf("\n===========================================\n");
      printf(" Name: %s\n Code: %d\n", materia[i].name,materia[i].code );
      printf(" Type: %s\n", materia[i].division);
      printf(" Theoretical credits: %.1f\n",materia[i].tCredits);
      printf(" Practical credits: %.1f\n", materia[i].pCredits);
      printf(" Total credits: %d\n",materia[i].totalCredits);
      printf(" Semester: %d\n",materia[i].semester);
	  
	  Vertex* vertex = &g->vertices[ i ];
	  
      printf( vertex->neighbors ? " -Serialized-\n" : " -Non-serialized-\n" );

      
      if( depth > 0 ){
       	
         for( Node* node = vertex->neighbors; node != NULL; node = node->next ){
      	
		    printf( "\nId: %s ", g->vertices[ node->index ].map.key );

            
		    if( depth > 1 ){
               printf( "(Node:%p) ", node );
               }printf( "->" );
            
         } if( vertex->neighbors ) printf( " None\n" );
      }
   } printf( "\n" );
}

void Graph_AddVertex( Graph* g, char* key, size_t index )
{

   assert( g->len < g->size );
   Vertex* vertex = &g->vertices[ g->len ];

   vertex->map.key = key;

   
   vertex->map.data_idx = index;
   vertex->neighbors    = NULL;
   ++g->len;
}

static int find( Vertex* vertices, size_t size, char* key )
{
   for( size_t i = 0; i < size; ++i ){
      if( strcmp( vertices[ i ].map.key , key) == 0 ) return i;
   }
   return -1;
}

bool find_index_in_vertex( Vertex* vertex, int index )
{
   for( Node* node = vertex->neighbors; node != NULL; node = node->next ){
      if( node->index == index ) return true;
   }
   return false;
}

static Node* insert( Vertex* vertex, int index )
{
	Node* n = NULL;
	
   if( find_index_in_vertex( vertex, index ) == false )
   {
      
      n = (Node*) calloc( 1, sizeof( Node ) );
      assert( n );
      
      
      n->index = index;
      n->next = vertex->neighbors;
      vertex->neighbors = n;
      
   } 
   else
   
   return n;
}

bool Graph_AddEdge( Graph* g, char* start, char* finish )
{
   assert( g->len > 0 ); 
  
   int start_idx = find( g->vertices, g->size, start );
   int finish_idx = find( g->vertices, g->size, finish );

   if( start_idx == -1 || finish_idx == -1 ) return false;
   
   
   insert( &g->vertices[ start_idx ], finish_idx );

 if( g->type == eGraphType_UNDIRECTED ) insert( &g->vertices[ finish_idx ], start_idx );


   return true;
}

Node* Graph_GetNeighborsByKey( Graph* g, char* key ) {
   for( size_t i = 0; i < g->len; ++i ){
      if( g->vertices[ i ].map.key == key ) return g->vertices[ i ].neighbors;
   }
   return NULL;
}

Vertex* Graph_GetVertexByKey( Graph* g, char* key )
{
   assert( g );
   for( size_t i = 0; i < g->len; ++i ){
      if( strcmp( g->vertices[ i ].map.key , key) == 0 ) return &g->vertices[ i ];
   }
   return NULL;
}

size_t Graph_GetIndex( Graph* g, Vertex* v )
{
   assert( g );
   if( v == NULL ) return -1;
   size_t index;
   for( index = 0; index < g->len; ++index ){
      if( g->vertices[ index ].map.key == v->map.key ) break;
   }
   assert( index < g->len );
   return index;
}
size_t Graph_GetLen( Graph* g )
{
   return g->len;
}

size_t Graph_GetSize( Graph* g )
{
   return g->size;
}

Vertex* Graph_GetVertexByIndex( Graph* g, size_t index )
{
   assert( g );
   assert( index < g->len );
   return &g->vertices[ index ];
}

size_t Vertex_Get( const Vertex* v )
{
   assert( v->cursor );
   return v->cursor->index;
}

void Vertex_Start( Vertex* v )
{
   assert( v );
   v->cursor = v->neighbors;
}

void Vertex_Next( Vertex* v )
{
   assert( v->cursor );
   v->cursor = v->cursor->next;
}

bool Vertex_End( const Vertex* v )
{
   return v->cursor == NULL;
}

size_t Vertex_GetDataIndex( Vertex* v )
{
   return v->map.data_idx;
}

