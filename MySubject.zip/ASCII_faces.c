#include "ASCII_faces.h"


void welcome(){
	
	for( int i=0; i<80; i++){
		printf("=");
	}
	
	printf("\n Welcome to My Subject!\n\n");
	printf(" In MySubject, you'll be able to explore the subjects imparted in the\n");
	printf(" Computer Engineering of the Engineering Faculty of the University City\n");
	printf(" of the National Autonomous University of Mexico\n\n");
	printf(" MySubject is dedicated especially to students that are trying to match\n");
	printf(" their subjects with these subjects of the Computer Engineering\n\n");
	printf(" Please, follow the instruction carefully so you can get proper feedback\n\n");
	printf(" Technicans are seeking for MySubject's betterment\n");
	
	getchar();
}

void info(){
	
   system("cls");
   for( int i=0; i<80; i++){
      printf("=");
   }
	
	printf("\n My Subject is a program for you to look up for your subjects in the");
	printf("\n Engineering Faculty at University City, in case you need to match them ");
	printf("\n due to a scholarship, for instance.\n ");
	printf("\n It is important to keep in mind that some subject might not be in the");
	printf("\n engineering's plans of study or might have been mispelled. In that case, ");
	printf("\n we suggest you to retype really carefully your subjects, becuase My Subject ");
	printf("\n is sensitive to capital letters.\n ");
	printf("\n If your answer does not get feedback, after correcting the spelling, ");
	printf("\n the subject you are trying to find might not exist or has been removed.\n ");
	printf("\n You'll find plenty of elective subjects along the different engineerings, ");
	printf("\n which will appear with that name. You can look for them in the");
	printf("\n Engineering Faculty official website, right down the curricular maps of");
	printf("\n any career. However, My Subject will still show its seriation and semester\n");
	printf("\n For more information, you can visit the official website of the Engineering");
	printf("\n Faculty: \n");
	printf("https://www.ingenieria.unam.mx/programas_academicos/licenciatura/computacion.php\n");

	
   for( int i=0; i<80; i++){
      printf("=");
   }
	
	
	getchar();
	system("cls");
}
