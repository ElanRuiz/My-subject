

typedef struct 
{
   char name[80]; 	 
   int code;          
   char division[50]; 
   float tCredits;
   float pCredits;
   int totalCredits;
   int semester;
   
} Subject;

typedef struct Node_
{
   size_t index;
   struct Node_ *next;
} Node;

typedef struct
{
   char*  key;
   size_t data_idx;
} Map;

typedef struct
{
   Map   map;
   Node* neighbors;
   Node* cursor;
} Vertex;

typedef enum 
{  eGraphType_UNDIRECTED,
   eGraphType_DIRECTED
} eGraphType;

typedef struct
{
   Vertex* vertices;
   size_t size;
   size_t len;  
   eGraphType type;
   
} Graph;


Graph* Graph_New( size_t size, eGraphType type );
void Graph_Delete( Graph** g );
void Graph_Print( Graph* g, int depth, Subject *materia );
void Graph_AddVertex( Graph* g, char* key, size_t index );
size_t Graph_GetSize( Graph* g );
static int find( Vertex* vertices, size_t size, char* key );
bool find_index_in_vertex( Vertex* vertex, int index );
static Node* insert( Vertex* vertex, int index );
bool Graph_AddEdge( Graph* g, char* start, char* finish );
Node* Graph_GetNeighborsByKey( Graph* g, char* key );
Vertex* Graph_GetVertexByKey( Graph* g, char* key );
Vertex* Graph_GetVertexByIndex( Graph* g, size_t index );
size_t Graph_GetIndex( Graph* g, Vertex* v );
size_t Graph_GetLen( Graph* g );
size_t Vertex_Get( const Vertex* v );
void Vertex_Start( Vertex* v );
void Vertex_Next( Vertex* v );
bool Vertex_End( const Vertex* v );
