#include "Graph.c"

#define SUBJECTS 48

void create_json( Subject* m, char* file_name, int idx );
void create_yaml( Subject* m, char* file_name, int idx );
void create_xml ( Subject* m, char* file_name, int idx );


void computerGraph( ){
	
	char *nomes4[] = { "Algebra","Calculus with Analytic Geometry",
	"Chemistry","Physics Fundamentals","Programming Fundamentals",
	"Linear Algebra","Integral Calculus","Mechanics",
	"Redaction and Reporting of Engineering Topics",
	"Data Structures and Algorithms I", "Probability",
	"Vectorial Calculus","Differential Equations",
	"Culture and Communication","Data Structures and Algorithms II",
	"Object-oriented Programming","Statistic Fundamentals",
	"Electricity and Magnetism","Numerical Analysis",
	"Advanced Math","Discrete Structures",
	"Structure and Programming of Computers",
	"Electronic Devices","Formal and Automata Languages",
	"Signs and Systems","Software Engineering",
	"Operating Systems","Modern Digital Design","Databases",
	"Electrical Circuits","Software Projects Administration",
	"Finances in Computer Engineering","VLSI Digital Design",
	"Artificial Intelligence","Compilers",
	"Communication Systems","Introduction to Economics",
	"Social Sciences and Humanities Elective Subject",
	"Microcomputers",
	"Graphical Computing and Human-computer Interaction",
	"Professional Ethics","Secure Data Networks",
	"Computers Organization and Architecture",
	"Embedded Systems Fundamentals","Distributed Systems",
	"Elective Subject from the Deepening Field",
	"Recources and needs of Mexico",
	"Elective Subjects from the Deepening Field" };
	
	int code4[48] = { 1120,1121,1123,1130,1122, 1220,1221,1228,
	1124,1227, 1436,1321,1325,1222,1317,1323, 1445,1414,1433,
	1424,119, 1503,138,442,1473,1531, 840,1645,1644,1562,1643,
	1537,1535,406,434,1686,1413, 0000,1672,1590,1052,1598,
	1867,1858,1959,0000,2080, 0000 };
	
	char *divisions4[] = { "Basic Sciences", "Basic Sciences",
	"Basic Sciences", "Basic Sciences","Other Convenient Subjects",
	"Basic Sciences","Basic Sciences","Basic Sciences",
	"Social Sciences and Humanities","Engineering Sciences",
	"Basic Sciences","Basic Sciences","Basic Sciences",
	"Social Sciences and Humanities","Engineering Sciences",
	"Other Convenient Subjects","Basic Sciences","Basic Sciences",
	"Basic Sciences","Basic Sciences","Engineering Sciences",
	"Engineering Sciences","Engineering Sciences",
	"Engineering Sciences","Engineering Sciences",
	"Engineering Sciences","Engineering Sciences",
	"Engineering Sciences","Engineering Sciences",
	"Engineering Sciences","Engineering Sciences",
	"Other Convenient Subjects","Engineering Sciences",
	"Applied Engineering","Applied Engineering",
	"Engineering Sciences","Social Sciences and Humanities",
	"Social Sciences and Humanities","Applied Engineering",
	"Applied Engineering","Social Sciences and Humanities",
	"Applied Engineering","Applied Engineering",
	"Applied Engineering","Applied Engineering",
	"Applied Engineering","Social Sciences and Humanities",
	"Applied Engineering" };

	float tCredits4[48] = { 4,6,4,2,4, 4,4,6,2,4, 4,4,4,0,4,4,
	4,4,4,4,4, 4,4,4,3,4, 4,4,6,3,4, 3,3,4,4,3,4, 2,3,4,2,6,
	3,3,4,4,4, 0 };

	float pCredits4[48] = { 0,0,2,2,2, 0,0,0,2,2, 0,0,0,2,2,2,
	0,2,0,0,0, 0,2,0,2,0, 0,2,2,2,0, 0,2,0,0,2,0, 2,2,2,2,2,
	2,2,0,0,0, 0 };
	
	int totalCredits4[48] = { 8,12,10,6,10, 8,8,12,6,10,
	8,8,8,2,10,10, 8,10,8,8,8, 8,10,8,8,8, 8,10,14,8,8,
	6,8,8,8,8,8, 6,8,10,6,14, 8,8,8,8,8, 40 };
	
	int semester4[48] = { 1,1,1,1,1, 2,2,2,2,2, 3,3,3,3,3,3,
	4,4,4,4,4, 5,5,5,5,5, 6,6,6,6,6, 7,7,7,7,7,7, 8,8,8,8,8,
	9,9,9,9,9, 10 };
	
    
	Subject materias[ SUBJECTS ];
    
   for( size_t i=0; i<SUBJECTS; ++i) {

		strcpy( materias[i].name, nomes4[i] );
      materias[i].code = code4[i];
      strcpy( materias[i].division, divisions4[i] );
      materias[i].tCredits = tCredits4[i];
      materias[i].pCredits = pCredits4[i];
      materias[i].totalCredits = totalCredits4[i];
		materias[i].semester = semester4[i];

   }
   
   Graph* g4 = Graph_New( SUBJECTS, eGraphType_DIRECTED );
   
   for( size_t i = 0; i <SUBJECTS; ++i )
   {
		Graph_AddVertex( 
   		g4,    
      	materias[i].name,
      	i );           
   }
   
   Graph_AddEdge( g4, "Algebra", "Linear Algebra" );
   Graph_AddEdge( g4, "Calculus with Analytic Geometry", 
   "Integral Calculus" );
   Graph_AddEdge( g4, "Calculus with Analytic Geometry", 
   "Mechanics" );
   Graph_AddEdge( g4, "Programming Fundamentals", 
   "Data Structures and Algorithms I" );
   Graph_AddEdge( g4, "Linear Algebra", "Probability" );
   Graph_AddEdge( g4, "Integral Calculus", 
   "Vectorial Calculus" );
   Graph_AddEdge( g4, "Integral Calculus", 
   "Differential Equations" );
   Graph_AddEdge( g4, "Data Structures and Algorithms I", 
   "Data Structures and Algorithms II" );
   Graph_AddEdge( g4, "Data Structures and Algorithms I", 
   "Object-oriented Programming" );
   Graph_AddEdge( g4, "Probability", "Statistic Fundamentals" );
   Graph_AddEdge( g4, "Vectorial Calculus", 
   "Electricity and Magnetism" );
   Graph_AddEdge( g4, "Differential Equations", 
   "Numerical Analysis" );
   Graph_AddEdge( g4, "Data Structures and Algorithms II", 
   "Discrete Structures" );
   Graph_AddEdge( g4, "Electricity and Magnetism", 
   "Electronic Devices" );
   Graph_AddEdge( g4, "Advanced Math", "Signs and Systems" );
   Graph_AddEdge( g4, "Structure and Programming of Computers", 
   "Operating Systems" );
   Graph_AddEdge( g4, "Formal and Automata Languages", 
   "Artificial Intelligence" );
   Graph_AddEdge( g4, "Formal and Automata Languages", 
   "Compilers" );
   Graph_AddEdge( g4, "Signs and Systems", "Electrical Circuits" );
   Graph_AddEdge( g4, "Signs and Systems", 
   "Communication Systems" );
   Graph_AddEdge( g4, "Software Engineering", 
   "Software Projects Administration" );
   Graph_AddEdge( g4, "Modern Digital Design", 
   "VLSI Digital Design" );
   Graph_AddEdge( g4, "VLSI Digital Design", "Microcomputers" );
   Graph_AddEdge( g4, "Communication Systems", 
   "Secure Data Networks" );
   Graph_AddEdge( g4, "Microcomputers", 
   "Computers Organization and Architecture" );
   Graph_AddEdge( g4, "Microcomputers", 
   "Embedded Systems Fundamentals" );
   int option,option2,j;
   
   do{
   
   do{
   char subject[70];
   printf("Please, type the subject you would want to have info about\n");
   gets(subject);
   
   Vertex* v = Graph_GetVertexByKey( g4, subject );
   int i = Graph_GetIndex( g4, v );
   
   if( i == -1 ){
   	printf("The subject typed might have been mispelled or does not exist\n\n");
   	printf(" Press ENTER to continue...\n");
   	getchar();
   	system("cls");
   	option = 0;
   }else{
   	j = i;
   	
   	printf("\n===========================================\n");
      printf(" Name: %s\n Code: %d\n", materias[i].name,materias[i].code );
      printf(" Type: %s\n", materias[i].division);
      printf(" Theoretical credits: %.1f\n",materias[i].tCredits);
      printf(" Practical credits: %.1f\n", materias[i].pCredits);
      printf(" Total credits: %d\n",materias[i].totalCredits);
      printf(" Semester: %d\n",materias[i].semester);
      
      do{
	  
      printf(" Would you like to access to this subject?\n1:Yes\n2:Try a new one\n");
      scanf("%d",&option);
      system("cls");
      }while( option != 1 && option != 2 );
   }
      
	}while(option != 1 );

	int archieve;

	do{
		char name[100];
      printf("Which archieve you would like your subject to be exported\n");
      printf("1:XML\n2:Json\n3:Yml\n");
      scanf("%d",&archieve);
      if( archieve == 1 ){
      	printf("Write your archieve's name with extension .xml\n");
      	scanf("%s",&name);
      	create_xml( &materias, name, j );
      	system("cls");
      	printf("Remember that your archieve should have had its proper extension in the end\n\n");
      }
      if( archieve == 2 ){
      	printf("Write your archieve's name with extension .json\n");
      	scanf("%s",&name);
      	create_json( &materias,name, j );
      	system("cls");
      	printf("Remember that your archieve should have had its proper extension in the end\n\n");
		}
		if( archieve == 3 ){
			printf("Write your archieve's name with extension .yml\n");
      	scanf("%s",&name);
      	create_yaml( &materias,name, j );
      	system("cls");
      	printf("Remember that your archieve should have had its proper extension in the end\n\n");
		}
				  
   }while( archieve != 1 && archieve != 2 && archieve != 3 );
   
   do{
   	
   option2 = 0;
   system("cls");
   printf("What would you like to do now?\n");
   printf("1:Look for another subject\n");
   printf("2:Load some subject\n");
   printf("3:Exit\n");
   scanf("%d",&option2);
   
	switch(option2){
   	case 2:
   		read_file( );
   		break;
   	case 3:
    		printf("Are you sure you want to leave?\n3:Yes\n2:No\n");
        	scanf("%d",&option2);
        	break;
   }
        
   }while( option2 != 3 && option2 != 1 );
   
   }while( option2 == 1 );
   
   Graph_Delete( &g4 );
   assert( g4 == NULL );	
	
}

void create_json( Subject* m, char* file_name, int idx ){
	
	FILE * archivo = fopen( file_name, "w" );
	
   if( archivo == NULL ){
		printf("Something went wrong when creating the archieve\n");
   }else{
   	
      fprintf(archivo,"{\n");
   	fprintf(archivo, " \"Engineering\" : \"Computer Engineering\",\n");
      fprintf(archivo, " \"Career code\" : 110,\n");
      fprintf(archivo, " \"Name\" : \"%s\",\n",m[idx].name);
      fprintf(archivo, " \"Code\" : %d,\n",m[idx].code);
      fprintf(archivo, " \"Type\" : \"%s\",\n",m[idx].division);
    
      fprintf(archivo, " \"Credits\" : [\n");
    	
    	fprintf(archivo,"    {\"Theoretical\" : %.1f, \"Practical\" : %.1f, \"Total\" : %d}",
		m[idx].tCredits,m[idx].pCredits,m[idx].totalCredits);

      fprintf(archivo,"\n ],\n");
	
	  	fprintf(archivo, " \"Semester\" : %d\n",m[idx].semester);
	  	fprintf(archivo,"}");
   }
}

void create_yaml( Subject* m, char* file_name, int idx ){
	
	FILE * archivo = fopen(file_name, "w");
	
	if( archivo == NULL ){
		printf("Something went wrong when creating the archieve\n");
	}else{

		fprintf(archivo, "---\n");
		fprintf(archivo, "Engineering: Computer Engineering\n");
		fprintf(archivo, "Career code: 110\n");
		fprintf(archivo, "Name: %s\n",m[idx].name);
		fprintf(archivo, "Code: %d\n",m[idx].code);
		fprintf(archivo, "Type: %s\n",m[idx].division);
		fprintf(archivo, "Credits:\n");
		
		fprintf(archivo, "  - Theoretical: %.1f\n",m[idx].tCredits);
		fprintf(archivo, "    Practical: %.1f\n",m[idx].pCredits);
		fprintf(archivo, "    Total: %d\n",m[idx].totalCredits);
		
		fprintf(archivo, "Semester: %d\n",m[idx].semester);
		fprintf(archivo, "...");
		
		printf("\n Archieve %s printed successfully\n",file_name);
      printf(" Press ENTER to continue...\n");
      getchar();
      system("cls");
	}
}

void create_xml( Subject* m, char* file_name, int idx ){
	
	FILE * archivo = fopen(file_name, "w");
	
	if( archivo == NULL ){
		printf("\n \n Something went wrong when creating the archieve\n");
	}else{

		fprintf(archivo, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		fprintf(archivo, "<Subject>\n");
		fprintf(archivo, "  <Engineering> Computer Engineering </Engineering>\n");
		fprintf(archivo, "  <CareerCode> 110 </CareerCode>\n");
		fprintf(archivo, "  <Name> %s </Name>\n",m[idx].name);
		fprintf(archivo, "  <Code> %d </Code>\n",m[idx].code);
		fprintf(archivo, "  <Type> %s </Type>\n",m[idx].division);
		fprintf(archivo, "    <Credits>\n");
		
		fprintf(archivo, "      <Theoretical> %.1f </Theoretical>\n",m[idx].tCredits);
		fprintf(archivo, "      <Practical> %.1f </Practical>\n",m[idx].pCredits);
		fprintf(archivo, "      <Total> %d </Total>\n",m[idx].totalCredits);
		
		fprintf(archivo, "    </Credits>\n");
		fprintf(archivo, "  <Semester> %d </Semester>\n",m[idx].semester);
		fprintf(archivo, "</Subject>\n");
		
	  	printf("\n Archieve %s printed successfully\n",file_name);
      printf(" Press ENTER to continue...\n");
      getchar();
      system("cls");
	}
}

void read_file( ){
	
	printf("Type carefully your archieve\n");
	char file_name[100];
	scanf("%s",&file_name);
	
   FILE * archivo = fopen( file_name, "r" );
	
   if( archivo == NULL ){
      printf("\n Something went wrong when reading the archieve\n");
   }else{
		
      char caracter;
		
      while( feof(archivo) == 0 ){
      	caracter = fgetc(archivo);
		 	printf("%c",caracter);
      }
		fclose(archivo);
      printf("\n Archieve %s printed successfully\n",file_name);
      printf(" Press ENTER to continue...\n");
      getchar();
      system("cls");
   }
}
