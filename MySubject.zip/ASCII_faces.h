#include<stdio.h>

void welcome();
void info();

