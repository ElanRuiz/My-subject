#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<time.h>
#include<stdbool.h>
#include<string.h>
#include<stdint.h>

#include "ASCII_faces.c"

#include "computerGraph.c"

int main(){
	
   welcome();
   info();

   computerGraph( );
   
   system("cls");
	printf(" Thank you for using MySubject\n");
	
	return 0;
}
